fun main() {
    val a = arrayOf(
        arrayOf("[0][0]", "[0][1]", "[0][2]"),
        arrayOf("[1][0]", "[1][1]", "[1][2]")
    )
    println(a.contentDeepToString())
}
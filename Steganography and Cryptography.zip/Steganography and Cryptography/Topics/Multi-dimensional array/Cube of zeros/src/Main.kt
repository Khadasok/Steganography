import java.io.File

fun main() {
    val cube = Array(3) { Array(3) { IntArray(3) } }
    println(cube.contentDeepToString())
    val sep = File.separator
    val note = File("c:${sep}Users${sep}khada${sep}android files${sep}Note.txt")
    note.writeText("\tNew txt file is created!")
    note.appendText("\nThat is exciting")
    println(note.readText())
}



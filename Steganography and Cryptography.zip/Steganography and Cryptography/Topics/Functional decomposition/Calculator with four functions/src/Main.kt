fun subtractTwoNumbers(a: Long, b: Long) {
    println(a - b)
}

fun sumTwoNumbers(a: Long, b: Long) {
    println(a + b)
}

fun divideTwoNumbers(a: Long, b: Long) {
    println(if (b == 0L) "Division by 0!" else a / b)
}

fun multiplyTwoNumbers(a: Long, b: Long) {
    println(a * b)
}
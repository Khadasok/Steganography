fun getFullNames() {
    val firstName = readLine()
    val lastName = readLine()
    println(createFullName(firstName, lastName))
}

fun createFullName(a: String?, b: String?): String = "$a $b"
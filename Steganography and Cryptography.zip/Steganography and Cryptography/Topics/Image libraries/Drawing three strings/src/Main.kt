import java.awt.Color
import java.awt.Graphics
import java.awt.image.BufferedImage

fun drawStrings(): BufferedImage {
    val image = BufferedImage(200, 200, BufferedImage.TYPE_INT_RGB)
    val graphics = image.createGraphics()
    val text = "Hello, images!"
    drawing(text, 50, 50, Color.RED, graphics)
    drawing(text, 51, 51, Color.GREEN, graphics)
    drawing(text, 52, 52, Color.BLUE, graphics)
    return image
}

fun drawing(text: String, x: Int, y: Int, color: Color, graphics: Graphics) {
    graphics.color = color
    graphics.drawString(text, x, y)
}
import java.awt.Color
import java.awt.image.BufferedImage

const val DIM = 200

fun drawLines(): BufferedImage {
    val height = DIM
    val width = DIM
    val image = BufferedImage(width, height, BufferedImage.TYPE_INT_RGB)
    val graphics = image.createGraphics()
    graphics.color = Color.RED
    graphics.drawLine(0, 0, DIM, DIM)
    graphics.color = Color.GREEN
    graphics.drawLine(DIM, 0, 0, DIM)
    return image
}
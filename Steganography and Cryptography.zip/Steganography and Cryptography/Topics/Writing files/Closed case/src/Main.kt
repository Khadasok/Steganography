// Write your code here. Do not import any libraries
val myFile = File("MyCases.txt")
myFile.appendText("\nThe Sign of the Four")
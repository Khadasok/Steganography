// Write your code here. Do not import any libraries
    val text = readLine()!!
    val name = "MyFile.txt"
    val myFile = File(name)
    myFile.writeText(text.repeat(2))

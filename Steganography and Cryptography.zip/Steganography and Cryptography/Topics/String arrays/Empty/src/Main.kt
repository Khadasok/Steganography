    val myEmptyArray = emptyArray<String>()

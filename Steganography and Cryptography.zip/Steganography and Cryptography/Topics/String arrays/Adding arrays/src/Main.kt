fun main() {
    var firstArray = readLine()!!.split(' ').map { it }.toTypedArray()
    val secondArray = readLine()!!.split(' ').map { it }.toTypedArray()
    firstArray += secondArray
    println(firstArray.joinToString())
}
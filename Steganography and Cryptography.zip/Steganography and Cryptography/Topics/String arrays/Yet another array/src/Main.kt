    val capitals = arrayOf("Tokyo", "Moscow", "Paris", "Washington", "Beijing")

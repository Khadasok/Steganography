import java.awt.Color
import java.awt.image.BufferedImage

fun main() {
    val height = 800
    val width = 800
    val image = BufferedImage(width, height, BufferedImage.TYPE_INT_RGB)
    val graphics = image.createGraphics()

    graphics.drawString("Playing with images", 80, 80)
    graphics.color = Color.ORANGE
}
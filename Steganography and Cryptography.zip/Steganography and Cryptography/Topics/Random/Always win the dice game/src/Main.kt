import kotlin.random.Random
@SuppressWarnings("MagicNumber")

fun createDiceGameRandomizer(n: Int): Int {
    var result = 0
    for (i in 1..100) {
        val seed = Random(i)
        var first = 0
        var second = 0
        repeat(n) { first += seed.nextInt(1, 7) }
        repeat(n) { second += seed.nextInt(1, 7) }
        if (second > first) result = i
    }
    return result
}

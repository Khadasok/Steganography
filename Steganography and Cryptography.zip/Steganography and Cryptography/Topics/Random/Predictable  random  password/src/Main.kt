import kotlin.random.Random
const val LENGTH = 9
const val MIN = 33
const val MAX = 127

fun generatePredictablePassword(seed: Int): String {
    val generator = Random(seed)
    var randomPassword = ""
    for (i in 0..LENGTH) {
        randomPassword += generator.nextInt(MIN, MAX).toChar()
    }
    return randomPassword
}

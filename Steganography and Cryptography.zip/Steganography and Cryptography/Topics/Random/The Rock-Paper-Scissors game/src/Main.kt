fun makeDecision(): String {
    val result = when ((1.."3".toInt()).random()) {
        1 -> "Rock"
        2 -> "Paper"
        else -> "Scissors"
    }
    return result
}

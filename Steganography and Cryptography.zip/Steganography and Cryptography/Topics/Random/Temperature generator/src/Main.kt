import kotlin.random.Random
const val DAYS = 7
const val MIN = 20
const val MAX = 31

fun generateTemperature(seed: Int): String {
    var result = ""
    val trick = Random(seed)
    repeat(DAYS) {
        result += if (result == "") trick.nextInt(MIN, MAX) else " ${trick.nextInt(MIN, MAX)}"
    }
    return result
}

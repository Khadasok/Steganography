import kotlin.random.Random

fun sumInts(): Int {
    var result = 0
    for (i in 1..100) {
        result += Random.nextInt(100)
    }
    return result
}

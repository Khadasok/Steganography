const val A = 100_000_000_001
const val B = 100_000_000_002
const val C = 100_000_000_003

fun main() {
    val longs = longArrayOf(A, B, C)
    println(longs.joinToString())
}
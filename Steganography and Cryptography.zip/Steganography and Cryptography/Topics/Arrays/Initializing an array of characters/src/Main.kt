fun main() {
    val characters = charArrayOf('a', 'z', 'e', 'd')
    println(characters.joinToString())
}
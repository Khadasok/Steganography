const val SIZE = 100
const val TEN = 10

fun main() {
    val numbers = IntArray(SIZE)
    numbers[0] = 1
    numbers[TEN - 1] = TEN
    numbers[SIZE - 1] = SIZE
    println(numbers.joinToString())
}
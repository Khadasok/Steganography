fun main() {
    val numbers = intArrayOf(12, 17, 8, 101, 33)
    println(numbers.joinToString())
}
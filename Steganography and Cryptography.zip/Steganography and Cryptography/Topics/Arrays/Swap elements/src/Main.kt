fun main() {    
    val numbers = readLine()!!.split(' ').map { it.toInt() }.toIntArray()
    val a = numbers.first()
    val b = numbers.last()
    numbers[0] = b
    numbers[numbers.lastIndex] = a
    println(numbers.joinToString(separator = " "))
}
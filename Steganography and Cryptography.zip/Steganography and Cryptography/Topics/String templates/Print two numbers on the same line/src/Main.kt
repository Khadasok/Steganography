fun main() {
    val a = readLine()!!.toInt()
    val b = readLine()!!.toInt()
    println("$a $b")
    // put your code here
}

fun main() {
    val num = readln().toInt()
    println("The obtained value is $num and its Int representation is ${num / 2}")
}
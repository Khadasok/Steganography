fun main() {
    val input = readLine()!!
    val num = input.length
    println("$num repetitions of the word $input: ${input.repeat(num)}")
    // write your code here
}

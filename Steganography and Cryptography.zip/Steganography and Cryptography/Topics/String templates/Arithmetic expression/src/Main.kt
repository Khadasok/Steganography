fun main() {
    val a = readLine()!!.toInt()
    val b = readLine()!!.toInt()
    val sum = a + b
    println("$a plus $b equals $sum")
    // write your code here
}

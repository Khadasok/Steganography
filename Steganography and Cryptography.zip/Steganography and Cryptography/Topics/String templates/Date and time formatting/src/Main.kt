import java.util.Scanner
fun main() {
    val scanner = Scanner(System.`in`)
    val hour = scanner.nextInt()
    val minutes = scanner.nextInt()
    val seconds = scanner.nextInt()
    val day = scanner.nextInt()
    val month = scanner.nextInt()
    val year = scanner.nextInt()
    println("$hour:$minutes:$seconds $day/$month/$year")

}

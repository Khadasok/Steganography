package cryptography

import java.awt.Color
import java.awt.image.BufferedImage
import java.io.File
import javax.imageio.ImageIO
import kotlin.system.exitProcess

fun main() {
    set()
}

fun set() {
    println("Task (hide, show, exit):")
    when (val task = readln()) {
        "hide" -> hide()
        "show" -> show()
        "exit" -> {
            println("Bye!")
            exitProcess(0)
        }
        else -> {
            println("Wrong task $task")
            set()
        }
    }
}

fun hide() {
    println("Input image file:")
    val inputFile = File(readln())
    if (!inputFile.exists()) {
        println("Can't read input file!")
        set()
    }
    println("Output image file:")
    val outputFile = File(readln())
    val image = ImageIO.read(inputFile)
    println("Message to hide:")
    val message = readln().encodeToByteArray()
    val mark = convertToBits(byteArrayOf(0, 0, 3))
    println("Password:")
    val key = readln().encodeToByteArray()
    val binaryMsg = convertToBits(message)
    val binaryKey = convertToBits(key)

    if (binaryMsg.length > image.height * image.width) {
        println("The input image is not large enough to hold this message.")
        set()
    }
    val encrypted = encrypt(binaryMsg, binaryKey)
    val newImage = hideMsg(image, encrypted + mark)

    ImageIO.write(newImage, "png", outputFile)
    println("Message saved in $outputFile image.")
    set()
}

fun convertToBits(message: ByteArray): String {
    var result = ""
    for (i in message.indices) {
        var num = Integer.toBinaryString(message[i].toInt())
        num = num.reversed() + "0".repeat(8 - num.length)
        result += num.reversed()
    }
    return result
}

fun encrypt(msg: String, pass: String): String {
    var result = ""
    var key = ""
        while (key.length < msg.length) {
        key += pass
    }
    for (i in msg.indices) {
        result += msg[i].code xor key[i].code
    }
    return result
}

fun hideMsg(image: BufferedImage, msg: String): BufferedImage {
    val newImage = BufferedImage(image.width, image.height, BufferedImage.TYPE_INT_RGB)
    var count = 0

    for (y in 0 until image.height) {
        for (x in 0 until image.width) {
            val color = Color(image.getRGB(x, y))
            if (count > msg.lastIndex) {
                newImage.setRGB(x, y, color.rgb)
            } else {
                val newColor = setColor(color, msg[count])
                newImage.setRGB(x, y, newColor.rgb)
                ++count
            }
        }
    }
    return newImage
}

fun setColor(color: Color, bit: Char): Color {
    val blue = when (bit) {
        '0' -> if (color.blue % 2 == 1) color.blue - 1 else color.blue
        else -> if (color.blue % 2 == 0) color.blue + 1 else color.blue
    }

    return Color(color.red, color.green, blue)
}

fun show() {
    println("Input image file:")
    val input = File(readln())
    val image = ImageIO.read(input)
    println("Password:")
    val key = convertToBits(readln().encodeToByteArray())
    val encrypted = convertToBits(decode(image))
    val decrypted = encrypt(encrypted, key)
    val byteMsg = convertToBytes(decrypted)
    val message = byteMsg.toString(Charsets.UTF_8)

    println("Message:")
    println(message)
    set()
}

fun decode(image: BufferedImage): ByteArray {
    var byteMsg = byteArrayOf()
    var bits = ""

    for (y in 0 until image.height) {
        for (x in 0 until image.width) {
            val color = Color(image.getRGB(x, y))
            if (byteMsg.size > 3
                && byteMsg.last() == 3.toByte()
                && byteMsg[byteMsg.lastIndex - 1] == 0.toByte()
                && byteMsg[byteMsg.lastIndex - 2] == 0.toByte()) {
                byteMsg.dropLast(3)
                return byteMsg
            }
            bits += if (color.blue % 2 == 0) 0 else 1
            if (bits.length == 8) {
                byteMsg += bits.toInt(2).toByte()
                bits = ""
            }
        }
    }
    return byteMsg
}

fun convertToBytes(msg: String): ByteArray {
    var result = byteArrayOf()
    var bits = ""
    for (i in msg) {
        bits += i
        if (bits.length == 8) {
            result += bits.toInt(2).toByte()
            bits = ""
        }
    }
    return result
}